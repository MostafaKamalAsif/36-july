# typed.js - example

A Pen created on CodePen.

Original URL: [https://codepen.io/merb/pen/yOwJjj](https://codepen.io/merb/pen/yOwJjj).

Found this awesome JavaScrip plug-in made by Matt Boldt and wanted to play around with it. Hope you like it.